"use client";
import { useEffect } from "react";
import { imageWithSize } from "../../helpers/api.config";
import Link from "next/link";
import { MediaTypeApi, IMediaData } from "@/Types/index";
import { useDispatch } from "react-redux";
import { setEdit } from "@/store/slices/listsManagementSlice";
import MediaCard from "./MediaCard";
import EditCheckbox from "./EditCheckbox";

interface MediaCardContainerProps {
  result: IMediaData;
  canBeEdited?: boolean;
  mediaType: MediaTypeApi;
  isChecked?: boolean;
  showBadge?: boolean; // <-- NUEVO
}

const MediaCardContainer = ({ result, canBeEdited = false, mediaType, isChecked, showBadge = false }: MediaCardContainerProps) => {
  // ... (tus imports y hooks quedan igual)
  const dispatch = useDispatch();

  const { media_type, id, poster_path, vote_average } = result;
  const poster = poster_path ? `${imageWithSize("780")}${poster_path}` : "";
  const vote = vote_average ? vote_average.toString().slice(0, 3) : "";

  // Agregamos showBadge a las props que viajan al MediaCard
  const mediaCardProps = { result, vote, poster, canBeEdited, showBadge };

  const isMovieOrTV = media_type == "movie" ? "movies" : "tvshows";

  useEffect(() => {
    return () => {
      dispatch(setEdit(false));
    };
  }, []);

  return (
    <div
      className={`relative rounded-md lg:hover:border lg:hover:border-brand-primary transition-all duration-200 ${isChecked ? "!border-[3px] !border-brand-primary hover:!border-[3px] rounded-md hover:!border-brand-primary" : "border border-white/10"}`}
      key={id}
      data-id={id}
    >
      <Link
        className="block h-full"
        href={`/${isMovieOrTV}/${id}`}
        onClick={() => {
          sessionStorage.setItem("navigatingFromApp", "1");
        }}
      >
        <MediaCard {...mediaCardProps} />
      </Link>

      {canBeEdited && <EditCheckbox id={id} />}
    </div>
  );
};

export default MediaCardContainer;
