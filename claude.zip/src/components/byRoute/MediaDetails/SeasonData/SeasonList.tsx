import { API_KEY, apiUrl, image } from "@/helpers/api.config";
import { getRunTime } from "@/helpers/getRunTime";
import { RootState } from "@/store";
import { MediaTypeApi } from "@/Types/index";
import { ImediaDetailsData } from "@/Types/mediaDetails";
import { Season } from "@/Types/season";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setEpisodesArray, setActiveSeason, setActiveEpisode } from "@/store/slices/mediaDetailsSlice";
import { setSeasonModal } from "@/store/slices/UISlice";
import { auth } from "@/firebase/firebase.config";
import { getWatchedEpisodeIds } from "@/firebase/getWatchedEpisodes";

function SeasonList({ data, mediaType, mediaId }: { data: ImediaDetailsData | null; mediaType: MediaTypeApi; mediaId: number }) {
  const router = useRouter();
  const { seasonModal } = useSelector((state: RootState) => state.ui);
  const { firebaseActiveUser } = useSelector((state: RootState) => state.auth);

  const seasonBtnRef = useRef<HTMLButtonElement | null>(null);
  const path = usePathname();

  const { episodesArray, activeSeason } = useSelector((state: RootState) => state.mediaDetails);
  const dispatch = useDispatch();
  const [watchedIds, setWatchedIds] = useState<Set<number>>(new Set());

  async function getSeasonData(season: number) {
    try {
      const seasonResponse = await fetch(`${apiUrl}${mediaType}/${mediaId}/season/${season}?api_key=${API_KEY}`);
      const json = await seasonResponse.json();
      dispatch(setEpisodesArray([json]));

      setTimeout(() => {
        if (seasonBtnRef.current) {
          seasonBtnRef.current.scrollIntoView({ behavior: "smooth" });
        }
      }, 1);
    } catch (error) {
      console.error("Error fetching season data:", error);
    }
  }
  useEffect(() => {
    if (activeSeason && activeSeason > 0 && seasonModal) {
      getSeasonData(activeSeason);
    }
  }, []);

  // Same "watched" tracking as the Episodes tab, so this modal shows it too.
  useEffect(() => {
    const uid = firebaseActiveUser?.uid || auth.currentUser?.uid;
    if (!uid) {
      setWatchedIds(new Set());
      return;
    }
    let cancelled = false;
    getWatchedEpisodeIds(uid, mediaId).then((ids) => {
      if (!cancelled) setWatchedIds(ids);
    });
    return () => {
      cancelled = true;
    };
  }, [mediaId, firebaseActiveUser?.uid]);

  if (!data) return null;

  return (
    <div className="w-full max-h-[50vh] lg:max-h-[70vh] overflow-auto flex flex-col gap-8 ">
      <h1 className="title font-semibold text-xl">{data.title}</h1>

      {data.seasonsArray &&
        data.seasonsArray.map((season: Season, index) => {
          const { episode_count, season_number } = season;
          if (season.name !== "Specials" && season.air_date && new Date(season.air_date).getTime() <= Date.now()) {
            return (
              <div className={`flex flex-col gap-2 w-full rounded-xl ${season_number === activeSeason ? " bg-zinc-950" : ""} p-2`} key={index}>
                <button
                  ref={season_number === activeSeason ? seasonBtnRef : null}
                  className={` rounded-lg p-4 w-full bg-surface-hover   border ${
                    activeSeason === season_number ? "text-brand-primary border-brand-primary" : "border-zinc-800 lg:hover:bg-zinc-950"
                  } flex  items-center justify-center `}
                  onClick={async () => {
                    if (activeSeason === season_number) {
                      dispatch(setActiveSeason(null));
                    } else {
                      dispatch(setEpisodesArray(null));
                      dispatch(setActiveSeason(season_number));
                    }
                    await getSeasonData(season_number);
                    if (seasonBtnRef.current) {
                      seasonBtnRef.current.scrollIntoView({ behavior: "smooth" });
                    }
                  }}
                >
                  <p className="">Season {season_number}</p>
                  <i className={`ml-auto ${activeSeason === season_number ? "bi bi-caret-up-fill" : "bi bi-caret-down-fill"}`}></i>
                </button>
                <div className={`flex items-start justify-center flex-wrap gap-4 ${activeSeason == season_number ? "h-full py-6" : "overflow-hidden h-0"}`}>
                  {Array.from({ length: episode_count ?? 0 }).map(
                    (_, index) =>
                      episodesArray?.[0].episodes?.[index] &&
                      new Date(episodesArray?.[0].episodes?.[index].air_date).getTime() <= Date.now() &&
                      (() => {
                        const ep = episodesArray[0].episodes[index];
                        const isWatched = watchedIds.has(ep.id);
                        return (
                          <button
                            key={index}
                            className="bg-zinc-900 px-2 hover:bg-zinc-700 py-2 lg:py-3 rounded-lg w-full"
                            onClick={() => {
                              dispatch(setActiveEpisode(index + 1));
                              dispatch(setSeasonModal(false));

                              router.push(`${path}/watch?season=${season_number}&episode=${index + 1}&option=1`);
                            }}
                          >
                            <div className="flex items-center justify-center gap-2 w-full">
                              <p>{index + 1}.</p>

                              <>
                                <div className="relative w-[40%] md:w-[25%] xl:w-[20%] h-full flex-shrink-0">
                                  <img src={`${image}${ep.still_path}`} className={`rounded-md object-cover w-full h-full ${isWatched ? "opacity-50" : ""}`} alt="" />
                                  {isWatched && (
                                    <>
                                      <span className="absolute top-1 right-1 flex items-center gap-1 bg-black/75 text-white text-[9px] px-1 py-0.5 rounded-full">
                                        <i className="bi bi-check-circle-fill text-brand-primary" />
                                      </span>
                                      <div className="absolute inset-x-0 bottom-0 h-1 bg-brand-primary rounded-b-md" />
                                    </>
                                  )}
                                </div>
                                <div className="flex flex-col gap-2 w-full">
                                  <div className="min-md:font-bold max-md:text-sm w-full flex items-center justify-center">
                                    <p className={`w-full h-full ${isWatched ? "text-zinc-500" : ""}`}>{ep.name}</p>
                                    <p className="text-right text-zinc-500 !text-[75%] h-full">{ep.runtime && getRunTime(ep.runtime)}</p>
                                  </div>
                                  <p className="max-lg:hidden text-zinc-400 xl:w-[75%] m-auto">{ep.overview}</p>
                                </div>
                              </>
                            </div>
                          </button>
                        );
                      })(),
                  )}
                </div>
              </div>
            );
          }
        })}
    </div>
  );
}

export default SeasonList;
